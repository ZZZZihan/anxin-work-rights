import type { CandidateNormalization, NormalizedCandidateValue, RawCandidateV3 } from './material-fact-types-v3.ts';
import { getCandidateLocalEvent, normalizeCandidateValue, normalizeMoneyValue } from './material-facts-v3.ts';
import { parseAmount } from './material-facts.ts';
import { moneyTokenHasNonCurrencyYuan, sourceMoneyHasNonCurrencyYuan, moneyTokenHasNonCurrencySubunit, isNonCurrencyAngleCountWord, isNonCurrencySubunitMeasure, sourceMoneyHasNonCurrencySubunit, isRmbCurrencyUnitAt, monetaryExpressionHasUnsupportedCurrency, sourceMoneyHasExplicitRmbCurrency, sourceMoneyHasUnsupportedCurrency } from './material-fact-currency-review.ts';
import { hasAttachedMoneyArithmetic } from './material-fact-arithmetic-review.ts';
import { MONEY_BOUND_PREFIX, MONEY_BOUND_SUFFIX, attachedMoneyQualifierStatus as attachedQualifierStatus, hasMoneyRange, isMoneyRangeEndpoint, moneyQualifierDetectionView } from './material-fact-range-review.ts';

export type MonetaryExpressionClassification = {
  kind: 'monetary' | 'not_monetary' | 'undetermined';
  normalization: CandidateNormalization;
};

const MAX_INPUT = 4000;
const LOWER_DIGITS = '零一二三四五六七八九';
const NUMERALS = '0-9零〇一二三四五六七八九十百千万萬亿億两兩壹贰貳叁參肆伍陆陸柒捌玖拾佰仟';
const LOWER = '零〇一二三四五六七八九十百千万萬亿億两兩';
const SINGLE_DIGIT = '零〇一二三四五六七八九两兩壹贰貳叁參肆伍陆陸柒捌玖';
const MASKED = /[xX×＊*]|未知|不详|不明|待定|无法确定|未提供|未明确|未载明|未记载|未披露|未列明|未注明|未约定|未确定|待确认|待核实|待补充|[?？□＿_]|\.{2,}|…/u;
const UNCERTAIN = /(?:可能|或许|大概|估计|不确定|待核|暂计|暂定)/u;
// An embedded 多/余 may prevent a complete exact token from matching.
// Other qualifiers are resolved at the token edges, never by their occurrence
// in an unrelated clause, a duration, or a name such as 最高人民法院.
const INNER_APPROXIMATE_MONEY = new RegExp(`[${NUMERALS}]+\\s*(?:多|余)(?:万|亿)?[元圆圓]`, 'u');
const RANGE_SPACE = String.raw`\s*`;
const RANGE_CURRENCY = '(?:人民币|人民幣|(?<![A-Z])(?:CNY|RMB)(?![A-Z])|¥)';
const RANGE_CURRENCIES = `(?:${RANGE_CURRENCY}${RANGE_SPACE})*`;
const RANGE_UNIT = `(?:元(?!旦|宵|年|月|素|件|音)|[圆圓](?!满|滿|形|圈|周))(?:${RANGE_SPACE}[${NUMERALS}]+[角分]){0,2}(?:整|正)?`;
// An explicit connector may continue over layout whitespace. This numeric
// fallback distinguishes an unfinished endpoint from a date or duration; the
// complete monetary endpoint grammar is shared with source review.
const RANGE_LINK = `${RANGE_SPACE}(?:${RANGE_UNIT}${RANGE_SPACE})?(?:${MONEY_BOUND_SUFFIX}${RANGE_SPACE})?${RANGE_CURRENCIES}(?:至|到|[~～—–-])${RANGE_SPACE}(?:(?:${RANGE_CURRENCY}|${MONEY_BOUND_PREFIX}|(?<!最)近)${RANGE_SPACE}){0,3}`;
const RANGE_NUMERIC_AFTER = new RegExp(`^${RANGE_LINK}[${NUMERALS}]`, 'iu');
const RANGE_TIME_AFTER = new RegExp(`^${RANGE_LINK}(?:[0-9]{4}[-/.][0-9]{1,2}(?:[-/.][0-9]{1,2})?(?![0-9])|[${NUMERALS}]+${RANGE_SPACE}(?:年|个?月|日|天|小时|分钟|秒))`, 'iu');

/** Share the established numeric-continuation fallback with source layout.
 * Complete monetary ranges are checked first by the endpoint guard. */
export function hasUnfinishedMoneyRangeAfter(after: string): boolean {
  const detection = monetaryDetectionView(after);
  return RANGE_NUMERIC_AFTER.test(detection) && !RANGE_TIME_AFTER.test(detection);
}

const RMB_NAME = '(?:人民[币幣]|(?<![A-Za-z])(?:RMB|CNY)(?![A-Za-z]))';
const ARABIC_DIGITS = '0-9０-９';
const LITERAL_NUMBER = `(?:(?:[${ARABIC_DIGITS}][${ARABIC_DIGITS},，]*(?:[.．][${ARABIC_DIGITS}]+)?)\\s*(?:万|萬|亿|億)?|[${LOWER}壹贰貳叁參肆伍陆陸柒捌玖拾佰仟]+)`;
const SUBUNITS = `(?:[${ARABIC_DIGITS}${SINGLE_DIGIT}]角(?:[${ARABIC_DIGITS}${SINGLE_DIGIT}]分)?|[${ARABIC_DIGITS}${SINGLE_DIGIT}]分)`;
const YUAN_TAIL = `[元圆圓](?:[${ARABIC_DIGITS}${SINGLE_DIGIT}]角)?(?:零?[${ARABIC_DIGITS}${SINGLE_DIGIT}]分)?(?:整|正)?`;
// New alternatives require an explicit named RMB currency. A bare 5角/2分
// remains unsupported; no time/measure unit is inferred to be money.
const TOKEN = new RegExp(`(?:${RMB_NAME}\\s*${SUBUNITS}(?:整|正)?|${SUBUNITS}(?:整|正)?\\s*${RMB_NAME}|(?:${RMB_NAME}|[¥￥])\\s*${LITERAL_NUMBER}(?:\\s*${YUAN_TAIL})?|${LITERAL_NUMBER}\\s*(?:${YUAN_TAIL}\\s*)?${RMB_NAME}|(?:人民[币幣]\\s*)?[¥￥]?\\s*${LITERAL_NUMBER}\\s*${YUAN_TAIL})`, 'giu');

function result(rawValue: string, status: CandidateNormalization['status'], reason: string, match?: { text: string; index: number; amount: string }): CandidateNormalization {
  return { rawValue, status, amount: match?.amount ?? null, matchedText: match?.text ?? null,
    span: match ? { start: Array.from(rawValue.slice(0, match.index)).length, end: Array.from(rawValue.slice(0, match.index + match.text.length)).length } : null, reason };
}

// Both full literals and clipped source values must consume a modifier before
// the numeric token. It cannot silently turn 数十万 or 负数四万 into its tail.
function monetaryDetectionView(value: string): string {
  // Fold only detection copies; keep line boundaries and every raw offset.
  return moneyQualifierDetectionView(value).replace(/[兩億詳無確認載記註實補暫計給發號時並併]/gu,
    glyph => ({ 兩: '两', 億: '亿', 詳: '详', 無: '无', 確: '确', 認: '认', 載: '载', 記: '记', 註: '注', 實: '实', 補: '补', 暫: '暂', 計: '计', 給: '给', 發: '发', 號: '号', 時: '时', 並: '并', 併: '并' })[glyph]!);
}

// Only uncertainty matching joins layout inside its finite existing words;
// punctuation and every other character remain barriers between events.
function uncertaintyDetectionView(value: string): string {
  return monetaryDetectionView(value).replace(/\s/gu, '');
}


function smallInteger(value: string): bigint | null {
  if (!value) return 0n;
  let total = 0n, digit: number | null = null, previousUnit = 10000;
  for (const character of value) {
    const n = LOWER_DIGITS.indexOf(character);
    if (n >= 0) {
      if (n === 0) { if (digit !== null) return null; continue; }
      if (digit !== null) return null;
      digit = n;
    } else {
      const unit = ({ 十: 10, 百: 100, 千: 1000 } as Record<string, number>)[character];
      if (!unit || unit >= previousUnit || (digit === null && (unit !== 10 || total !== 0n))) return null;
      total += BigInt(digit ?? 1) * BigInt(unit); digit = null; previousUnit = unit;
    }
  }
  return total + BigInt(digit ?? 0);
}

function lowerSpelling(value: bigint): string {
  if (value === 0n) return '零';
  const small = (n: number) => {
    let output = '', zero = false;
    for (const [unit, label] of [[1000, '千'], [100, '百'], [10, '十'], [1, '']] as const) {
      const digit = Math.floor(n / unit); n %= unit;
      if (digit) { if (zero) output += '零'; output += LOWER_DIGITS[digit] + label; zero = false; }
      else if (output && n) zero = true;
    }
    return output;
  };
  const chunks: number[] = [];
  let n = value;
  while (n) { chunks.push(Number(n % 10000n)); n /= 10000n; }
  let output = '', zero = false;
  for (let index = chunks.length - 1; index >= 0; index--) {
    const chunk = chunks[index];
    if (!chunk) { if (output) zero = true; continue; }
    if (output && (zero || chunk < 1000)) output += '零';
    output += small(chunk) + ['', '万', '亿'][index]; zero = false;
  }
  return output.startsWith('一十') ? output.slice(1) : output;
}

/** Lowercase Arabic-style Chinese integers are checked against their complete spelling.
 * Aliases are local to this parser; no repaired string is sent to the frozen normalizer.
 */
function lowerInteger(value: string): bigint | null {
  if (/两十|十两/u.test(value)) return null;
  const canonicalDigits = Array.from(value, character => character === '〇' ? '零' : character === '两' ? '二' : character).join('');
  const parseWan = (text: string): bigint | null => {
    const parts = text.split('万');
    if (parts.length > 2) return null;
    if (parts.length === 1) return smallInteger(text);
    const high = smallInteger(parts[0]), low = smallInteger(parts[1]);
    return high === null || low === null || high === 0n ? null : high * 10000n + low;
  };
  const parts = canonicalDigits.split('亿');
  if (parts.length > 2) return null;
  let yuan: bigint | null;
  if (parts.length === 1) yuan = parseWan(canonicalDigits);
  else {
    const high = parseWan(parts[0]), low = parseWan(parts[1]);
    yuan = high === null || low === null || high === 0n || high >= 10000n ? null : high * 100000000n + low;
  }
  if (yuan === null) return null;
  const spelling = lowerSpelling(yuan);
  return canonicalDigits === spelling || (spelling.startsWith('十') && canonicalDigits === `一${spelling}`) ? yuan : null;
}

function subunitDigit(character: string | undefined): bigint {
  if (character === undefined || character === '〇') return 0n;
  if (character === '两') return 2n;
  const lower = LOWER_DIGITS.indexOf(character), upper = '零壹贰叁肆伍陆柒捌玖'.indexOf(character);
  return lower >= 0 ? BigInt(lower) : upper >= 0 ? BigInt(upper) : BigInt(character);
}

function amountWithSubunits(yuan: bigint, jiao: string | undefined, zero: string | undefined, fen: string | undefined): string | null {
  // A zero may bridge an omitted jiao, not introduce a second fen digit or
  // follow an explicit jiao. Redundant 零零/零〇分 remain unsupported.
  if (zero && (jiao !== undefined || subunitDigit(fen) === 0n)) return null;
  const cents = yuan * 100n + subunitDigit(jiao) * 10n + subunitDigit(fen);
  return parseAmount(`${cents / 100n}.${String(cents % 100n).padStart(2, '0')}`)?.amount ?? null;
}

function parseLowerAmount(text: string): string | null {
  const match = text.match(new RegExp(`^(?:人民币\\s*)?[¥￥]?\\s*([${LOWER}]+)\\s*[元圆](?:([0-9${SINGLE_DIGIT}])角)?(?:(零?)([0-9${SINGLE_DIGIT}])分)?(?:整|正)?$`, 'u'));
  if (!match) return null;
  const yuan = lowerInteger(match[1]);
  return yuan === null ? null : amountWithSubunits(yuan, match[2], match[3], match[4]);
}

/** Whole Arabic yuan plus single-digit subunits; never add to a decimal/scaled
 * yuan token or infer omitted units. Keep cents exact through the range check.
 */
function parseArabicSubunits(text: string): string | null {
  const match = text.match(new RegExp(`^(?:人民币\\s*)?[¥￥]?\\s*((?:\\d{1,3}(?:[,，]\\d{3})+|\\d+))\\s*[元圆](?:([0-9${SINGLE_DIGIT}])角)?(?:(零?)([0-9${SINGLE_DIGIT}])分)?(?:整|正)?$`, 'u'));
  if (!match || (match[2] === undefined && match[4] === undefined)) return null;
  return amountWithSubunits(BigInt(match[1].replace(/[,，]/gu, '')), match[2], match[3], match[4]);
}

function parseFinancialSubunits(text: string): string | null {
  const match = text.match(new RegExp(`^(?:人民币\\s*)?[¥￥]?\\s*([零壹贰叁肆伍陆柒捌玖拾佰仟万亿]+)\\s*[元圆](?:([0-9${SINGLE_DIGIT}])角)?(?:(零?)([0-9${SINGLE_DIGIT}])分)?(?:整|正)?$`, 'u'));
  if (!match) return null;
  // Reuse the frozen canonical financial-integer grammar for the yuan part;
  // do not invent a second upper-case numeral parser or repair shorthand.
  const yuan = normalizeMoneyValue(`${match[1]}元`);
  return yuan.status === 'exact' && yuan.amount?.endsWith('.00')
    ? amountWithSubunits(BigInt(yuan.amount.slice(0, -3)), match[2], match[3], match[4]) : null;
}

function parseExplicitRmbSubunits(text: string): string | null {
  const prefix = text.match(new RegExp(`^${RMB_NAME}\\s*`, 'iu'));
  const postfix = text.match(new RegExp(`\\s*${RMB_NAME}$`, 'iu'));
  // Exactly one explicit currency edge belongs to this complete subunit token.
  // Only the parsing copy is sliced; returned spans still include its marker.
  if (!!prefix === !!postfix) return null;
  const literal = prefix ? text.slice(prefix[0].length) : text.slice(0, postfix!.index).trimEnd();
  const match = literal.match(new RegExp(`^(?:([0-9${SINGLE_DIGIT}])角(?:([0-9${SINGLE_DIGIT}])分)?|([0-9${SINGLE_DIGIT}])分)(?:整|正)?$`, 'u'));
  return match ? amountWithSubunits(0n, match[1], undefined, match[2] ?? match[3]) : null;
}

function remainingNumbers(rawValue: string, index: number, text: string): string {
  // Work only on a separate validation view. Returned spans always address the original string.
  const rest = (rawValue.slice(0, index) + '\u0000' + rawValue.slice(index + text.length)).normalize('NFKC');
  const count = `[${NUMERALS}]+`;
  return rest.replace(/\d{4}[-/.]\d{1,2}(?:[-/.]\d{1,2})?/gu, '')
    // 陆 is also a financial numeral; the complete ordinary 内陆 word does
    // not introduce a second number after an already anchored amount.
    .replace(/内[陆陸]/gu, '')
    .replace(new RegExp(`${count}\\s*年(?:\\s*${count}\\s*月(?:\\s*${count}\\s*日)?)?`, 'gu'), '')
    .replace(new RegExp(`${count}(?:\\.\\d+)?\\s*(?:个?月|天|日|小时|分钟|秒|件|(?:个|名|位)(?:工人|员工|劳动者)|名|人|倍|年)`, 'gu'), '');
}

/** A complete amount can precede a finite payment instruction. This only
 * distinguishes its following count/duration from another monetary digit;
 * currency, uncertainty, range and arithmetic guards still run separately. */
const PAYMENT_INSTRUCTION = `(?:一次性|一并|[${NUMERALS}]+\\s*(?:日|天)\\s*内)\\s*(?:支付|付清|给付|发放)`;
function isPostposedMoneyPaymentInstruction(after: string): boolean {
  const detection = monetaryDetectionView(after);
  return new RegExp(`^\\s*${PAYMENT_INSTRUCTION}(?=\\s*(?:$|[，,。；;！!）)】\\]]))`, 'u').test(detection);
}

function hasCompleteMoneyUnit(token: string): boolean {
  return /[元圆圓角分](?:整|正)?$/u.test(token);
}

/** Count only named RMB labels attached to this monetary token's edges.
 * One label is valid; a second cannot be discarded by a clipped value or
 * quote. Detection folding joins layout/Cf only, never intervening prose. */
function hasRepeatedRmbCurrency(before: string, token: string, after: string): boolean {
  const beforeView = monetaryDetectionView(before), tokenView = monetaryDetectionView(token);
  let count = [...tokenView.matchAll(new RegExp(RMB_NAME, 'giu'))].length;
  // A newly supported bare symbol already supplies its omitted yuan unit.
  // It cannot borrow another named prefix/suffix after cropping that marker;
  // existing symbol + explicit-yuan spellings retain their original contract.
  if (/^[¥￥]/u.test(tokenView) && !/[元圆圓角分]/u.test(tokenView)) count++;
  if (new RegExp(`${RMB_NAME}\\s*$`, 'iu').test(beforeView)) count++;
  // A bare Arabic value may omit its one yuan unit; an explicit whole-amount
  // ending can also precede the first named suffix. Neither adds a currency.
  let tail = monetaryDetectionView(after).replace(/^\s*(?:[元圆圓]\s*)?(?:[整正]\s*)?/u, '');
  const suffix = new RegExp(`^\\s*${RMB_NAME}\\s*`, 'iu');
  while (count < 2) {
    const match = tail.match(suffix);
    if (!match) break;
    count++; tail = tail.slice(match[0].length);
  }
  return count > 1;
}

/** Remove only a uniquely anchored two-character owner at this clause's
 * heading from the qualifier detection copy. This is not general name/entity
 * recognition: a missing, repeated, longer or modifier-shaped subject cannot
 * erase an actual bound. Raw strings and every normalization offset stay intact. */
export function moneyQualifierPrefixWithoutSubject(before: string, subject: string | null): string {
  if (!subject || !/^\p{Script=Han}[近约約]$/u.test(subject)
    || new RegExp(`^(?:${MONEY_BOUND_PREFIX}|近)$`, 'u').test(monetaryDetectionView(subject))) return before;
  const clause = before.split(/[，,。！？!?；;]/u).at(-1)!;
  const at = clause.indexOf(subject);
  if (at < 0 || clause.indexOf(subject, at + subject.length) >= 0) return before;
  const heading = clause.slice(0, at);
  if (!/^[\s\p{Extended_Pictographic}\uFE0F]*(?:(?:劳动者|勞動者|员工|員工|工人|原告|姓名)\s*[:：]?\s*)?$/u.test(heading)) return before;
  // Complete source name followed immediately by a finite wage bridge. A
  // second 约/近 or another genuine qualifier remains after the removed name.
  if (!/^\s*(?:的\s*)?(?:工[资資]|基本工[资資]|薪酬|薪[资資]|应付|應付|收到|领取|領取)/u.test(clause.slice(at + subject.length))) return before;
  const offset = before.length - clause.length + at;
  return before.slice(0, offset) + before.slice(offset + subject.length);
}

/** Parse one complete RMB literal with exact cents, preserving the unmodified evidence. */
export function normalizeMoneyValueV4(rawValue: string): CandidateNormalization {
  return normalizeMoneyValueWithSubject(rawValue, null);
}

function normalizeMoneyValueWithSubject(rawValue: string, subject: string | null): CandidateNormalization {
  if (rawValue.length > MAX_INPUT) return result(rawValue, 'unsupported', '金额原文超过4000字符上限，未尝试解析或截断。');
  if (monetaryExpressionHasUnsupportedCurrency(rawValue) || /±/u.test(rawValue)) return result(rawValue, 'unsupported', '仅支持明确人民币金额，外币、币种冲突和正负范围符号未转换。');
  if (/[％%]|百分之/u.test(rawValue)) return result(rawValue, 'percentage', '比例不能作为精确金额。');
  const isRange = hasMoneyRange(monetaryDetectionView(rawValue));
  const matches = [...rawValue.matchAll(new RegExp(TOKEN.source, TOKEN.flags))];
  // An explicit operation is distinct from a redaction: ×/x/* must not hide
  // the fact that the matched amount is only an operand. Keep raw indices.
  if (!isRange && matches.length === 1) {
    const match = matches[0];
    if (hasAttachedMoneyArithmetic(rawValue.slice(0, match.index), rawValue.slice(match.index + match[0].length))) return result(rawValue, 'unsupported', '金额直接参与倍数或算式，未把其中的金额操作数当作计算结果。');
  }
  if (MASKED.test(uncertaintyDetectionView(rawValue))) return result(rawValue, 'masked', '金额未知、未明确或被遮盖；保留原文且不转换为零。');
  if (UNCERTAIN.test(uncertaintyDetectionView(rawValue))) return result(rawValue, 'uncertain', '金额有不确定或待核表述。');
  if (isRange) return result(rawValue, 'range', '金额属于区间，未选取单个端点。');
  if (matches.length === 0 && INNER_APPROXIMATE_MONEY.test(monetaryDetectionView(rawValue))) return result(rawValue, 'approximate', '金额含多或余的内嵌概数，未转成精确金额。');

  if (matches.length > 1) return result(rawValue, 'multiple_amounts', '原文含多笔金额，无法唯一选取。');
  if (matches.length === 1) {
    const match = matches[0], text = match[0].trimStart(), index = match.index + match[0].length - text.length;
    const before = rawValue.slice(0, index).trimEnd(), after = rawValue.slice(index + text.length);
    if (moneyTokenHasNonCurrencyYuan(text, after)) return result(rawValue, 'unsupported', '匹配到的元或圆属于完整普通词语，不能截成金额单位。');
    if (moneyTokenHasNonCurrencySubunit(text, after)) return result(rawValue, 'unsupported', '匹配到的角或分属于时间、计量或普通词语，未作为分币金额。');
    const suffixRate = attachedSuffixRate(after);
    if (suffixRate.present && !suffixRate.supported) return result(rawValue, 'unsupported', '金额直接附着不受支持的费率分母，未将分子当作总额。');
    const qualifierStatus = attachedQualifierStatus(moneyQualifierPrefixWithoutSubject(before, subject), monetaryDetectionView(after));
    if (qualifierStatus) return result(rawValue, qualifierStatus, '完整金额带有数量不定、概数界限或正负限定，未截取其中的精确正数。');
    const yuanAt = text.search(/[元圆圓]/u);
    if (yuanAt >= 0 && !isRmbCurrencyUnitAt(rawValue, index + yuanAt)) return result(rawValue, 'unsupported', '匹配到的元或圆属于普通词语，不能截成金额单位。');
    if (new RegExp(`[${NUMERALS}０-９,.，负負+＋\\-－−﹣¥￥]$`, 'u').test(before)
      || (new RegExp(`^[${NUMERALS}０-９元圆圓角分整正]|^[,.，]\\s*[${NUMERALS}０-９]`, 'u').test(after)
        && !(hasCompleteMoneyUnit(text) && isPostposedMoneyPaymentInstruction(after)))) return result(rawValue, 'unsupported', '完整金额的数字、单位或符号边界不合法，未截取其中有效片段。');
    const rest = remainingNumbers(rawValue, index, text)
      .replace(/(?:一共|一次性|一[并並併]|同一|唯一|统一|另一笔|一笔)/gu, '')
      .replace(new RegExp(`第[${NUMERALS}]+(?:笔|次|项|条|人)`, 'gu'), '');
    if (new RegExp(`[${NUMERALS}０-９]`, 'u').test(rest)) return result(rawValue, 'multiple_amounts', '原文仍有无法解释为日期、计数或倍数的数字，可能存在省略币种的另一笔金额或复杂中文数表达。');
    if (hasRepeatedRmbCurrency(before, text, after)) return result(rawValue, 'unsupported', '金额重复附着币种标记，未截取其中一个完整片段。');
    // Currency spelling aliases exist only in this parse copy after the raw
    // token is anchored. Returned evidence and code-point spans use text/rawValue.
    let parseText = text.replace(/[０-９．]/gu, glyph => glyph === '．' ? '.' : String(glyph.charCodeAt(0) - 0xff10))
      .replace(/^人民幣/u, '人民币').replace(/圓/gu, '圆').replace(/萬/gu, '万').replace(/億/gu, '亿').replace(/兩/gu, '两').replace(/[貳參陸]/gu, glyph => ({ 貳: '贰', 參: '叁', 陸: '陆' })[glyph]!);
    const subunitAmount = parseExplicitRmbSubunits(parseText);
    const prefix = parseText.match(new RegExp(`^${RMB_NAME}\\s*`, 'iu'));
    // Explicit named RMB supplies the omitted yuan unit, only after the whole
    // original token and its continuation have passed the existing guards.
    if (prefix) {
      parseText = '人民币' + parseText.slice(prefix[0].length);
      if (!/[元圆角分整正]$/u.test(parseText)) parseText += '元';
    }
    // A postfix currency label is replaced only in this parse copy, after the
    // complete original token has been anchored. Never change returned spans.
    const postfix = parseText.match(new RegExp(`\\s*${RMB_NAME}$`, 'iu'));
    if (postfix) {
      parseText = parseText.slice(0, postfix.index).trimEnd();
      if (!/[元圆角分整正]$/u.test(parseText)) parseText += '元';
    }
    const onlyLower = new RegExp(`^(?:人民币\\s*)?[¥￥]?\\s*[${LOWER}]+\\s*[元圆][0-9${LOWER}${SINGLE_DIGIT}角分整正]*$`, 'u').test(parseText);
    const onlyFinancial = new RegExp(`^(?:人民币\\s*)?[¥￥]?\\s*[零壹贰叁肆伍陆柒捌玖拾佰仟万亿]+\\s*[元圆][0-9${SINGLE_DIGIT}角分整正]*$`, 'u').test(parseText);
    const parsed = subunitAmount ?? (onlyLower ? parseLowerAmount(parseText) : onlyFinancial ? parseFinancialSubunits(parseText) : parseArabicSubunits(parseText) ?? normalizeMoneyValue(parseText).amount);
    return parsed ? result(rawValue, 'exact', '唯一完整人民币金额已精确解析；原文和位置保持不变。', { text, index, amount: parsed })
      : result(rawValue, 'unsupported', '金额语法、精度或数值范围不受支持，未猜测省略位数。');
  }
  // Retain the frozen implementation's bare-Arabic-number compatibility only for a whole value.
  return normalizeMoneyValue(rawValue);
}

/** Adds source-bound qualifier checks without modifying source text or frozen representations. */
/** An immediately following uncertainty marker can be cropped out of value
 * and quote. Inspect a detection copy, retaining punctuation as evidence. */
export function hasPostposedMoneyUncertainty(after: string): boolean {
  // ×/x/* also occur in redactions. An explicit attached operation keeps
  // its established unsupported status instead of becoming a masked value.
  if (hasAttachedMoneyArithmetic('', after)) return false;
  const detection = uncertaintyDetectionView(after);
  // A supported slash/每 denominator cannot hide the same directly attached
  // unknown marker. Consume one finite rate wrapper only; clause punctuation
  // and another person's prose remain barriers in the existing predicate.
  const rate = detection.match(/^(?:[元圆圓])?(?:\/|每)(?:小时|[个個]?月|日|天|时|件)(?:计算|计酬|计价|计薪|计)?/u);
  const text = rate ? detection.slice(rate[0].length) : detection;
  if (rate && hasAttachedMoneyArithmetic('', text)) return false;
  return new RegExp(`^\\s*(?:[元圆圓]|人民币|人民幣|RMB|CNY)?\\s*[()[\\]{}【】]*\\s*(?:(?:金[额額]|[数數][额額])\\s*(?:为|為|是|[:=])?\\s*)?(?:${MASKED.source}|${UNCERTAIN.source})`, 'iu').test(text);
}

const RATE_UNITS: Record<string, RawCandidateV3['rateUnit']> = { 小时: 'hour', 月: 'month', 日: 'day', 天: 'day', 时: 'hour', 件: 'piece' };

/** A bounded calendar payment instruction is not a monthly denominator.
 * Source review reuses this detection-only predicate; amounts and raw offsets
 * are unaffected, and slash units and ordinary monthly rates remain guarded. */
export function isPostposedMoneyPaymentSchedule(after: string): boolean {
  const day = '(?:[12][0-9]|3[01]|[1-9]|二十[一二三四五六七八九]?|三十一?|十[一二三四五六七八九]?|[一二三四五六七八九])';
  const detection = monetaryDetectionView(after);
  const calendar = detection.match(new RegExp(`^\\s*(?:[元圆圓]\\s*)?每\\s*[个個]?月\\s*(?:第\\s*)?${day}\\s*(?:日|号)\\s*(?:支付|发放|给付|付清|发薪)`, 'u'));
  if (!calendar) return false;
  const tail = detection.slice(calendar[0].length);
  return /^\s*(?:$|[，,。；;！!）)】\]])/u.test(tail) && !hasPostposedMoneyUncertainty(tail);
}

function attachedSuffixRate(after: string) {
  const detection = monetaryDetectionView(after).replace(/[^\S\r\n\u2028\u2029]/gu, '');
  if (isPostposedMoneyPaymentSchedule(detection)) return { present: false, supported: undefined, postposedBy: false, uncertain: false };
  // 按时支付 is ordinary prose, and 按月15日 is a payment schedule.
  // Only a complete unit plus this finite pricing ending (or an unambiguous
  // bare unit at a clause boundary) creates a new denominator.
  const byDetection = detection.replace(/[時計價]/gu, character => ({ 時: '时', 計: '计', 價: '价' })[character]!);
  const by = byDetection.match(/^\s*(?:[元圆圓]\s*)?按\s*(?:(小时|月|日|天|件)(?:\s*(?:计算|计酬|计价|计薪|计))?|(时)\s*(?:计算|计酬|计价|计薪|计))/u);
  const byTail = by ? byDetection.slice(by[0].length) : '';
  const uncertain = by !== null && hasPostposedMoneyUncertainty(byTail);
  if (by && (/^\s*(?:$|[，,。；;！!？?）)】\]])/u.test(byTail) || uncertain))
    return { present: true, supported: by[1] ?? by[2], postposedBy: true, uncertain };
  // Known denominators may be bare at a clause boundary. Other bounded unit
  // names require an explicit pricing ending: ordinary 按... prose cannot
  // create a rate merely because it follows an amount.
  const unsupportedExpressions = [
    /^\s*(?:[元圆圓]\s*)?按\s*(?:年(?:度)?|周|週|星期|季度|季|次|分钟|分鐘|秒|公里|人|班)(?:\s*(?:计算|计酬|计价|计薪|计))?/u,
    /^\s*(?:[元圆圓]\s*)?按\s*(?:[\p{Script=Han}]{1,12}|[A-Za-z]{1,16})\s*(?:计算|计酬|计价|计薪|计)/u,
  ];
  for (const expression of unsupportedExpressions) {
    const unsupported = byDetection.match(expression);
    const tail = unsupported ? byDetection.slice(unsupported[0].length) : '';
    const uncertain = unsupported !== null && hasPostposedMoneyUncertainty(tail);
    if (unsupported && (/^\s*(?:$|[，,。；;！!？?）)】\]])/u.test(tail) || uncertain))
      return { present: true, supported: undefined, postposedBy: true, uncertain };
  }
  const suffix = detection.match(/^\s*(?:[元圆圓]\s*)?(?:\/|每)\s*([\p{L}]+)/u);
  const text = suffix?.[1];
  // A denominator is a complete lexical unit. 月亮/月份/小时候 cannot
  // borrow the enum from a valid prefix. Keep the existing finite pricing or
  // payment prose, and attached uncertainty, after a complete supported unit.
  const unit = text?.match(/^(小时|[个個]?月|日|天|时|件)/u);
  const remainder = unit ? text!.slice(unit[0].length) : '';
  const supported = unit && (remainder === '' || hasPostposedMoneyUncertainty(remainder)
    || attachedQualifierStatus('', remainder) !== null
    || /^(?:计算|计酬|计价|计薪|计|支付|发放|付清)$/u.test(remainder)) ? unit[1].replace(/^[个個](?=月$)/u, '') : undefined;
  return { present: suffix !== null, supported, postposedBy: false,
    uncertain: supported !== undefined && hasPostposedMoneyUncertainty(detection) };
}

/** Source layout uses the same complete suffix-unit classification. */
export function hasUnsupportedMoneySuffixRate(after: string): boolean {
  const rate = attachedSuffixRate(after);
  // Source layout can stop at a dangling 每 when the next fragment is not
  // safely attached. It cannot turn this explicitly begun denominator into a
  // total; local quote parsing still lets a complete source resolve the unit.
  return rate.present && rate.supported === undefined
    || /^[^\S\r\n\u2028\u2029]*(?:[元圆圓][^\S\r\n\u2028\u2029]*)?每\s*$/u.test(monetaryDetectionView(after));
}

export function supportedMoneySuffixRateUnit(after: string): RawCandidateV3['rateUnit'] | null {
  const rate = attachedSuffixRate(after);
  return rate.supported ? RATE_UNITS[rate.supported] : null;
}

/** A single 整/正 may end a complete amount, but cannot hide its continuation.
 * Only detection edges are joined here. The caller's raw normalization, quote,
 * source text and CP offsets are never rewritten or returned from this guard. */
export function hasUnsafeWholeMoneyContinuation(candidate: Pick<RawCandidateV3, 'meaning' | 'rateUnit'>, normalized: CandidateNormalization, after: string): boolean {
  if (!normalized.span) return false;
  const token = Array.from(normalized.rawValue).slice(normalized.span.start, normalized.span.end).join('');
  const tokenView = monetaryDetectionView(token), detection = monetaryDetectionView(after);
  // Source review supplies this complete layout edge even when value and
  // quote stop before a repeated suffix in the next line or adjacent block.
  if (hasRepeatedRmbCurrency('', token, after)) return true;
  // Source-local text can end before a question mark. The complete layout
  // edge must satisfy the same bounded payment ending before this exception.
  if (hasCompleteMoneyUnit(tokenView) && new RegExp(`^\\s*${PAYMENT_INSTRUCTION}`, 'u').test(detection)
    && !isPostposedMoneyPaymentInstruction(detection)) return true;
  const ending = /[元圆圓角分]$/u.test(tokenView) ? detection.match(/^\s*[整正]/u)
    : /[元圆圓角分][整正]$/u.test(tokenView) ? null : detection.match(/^\s*[元圆圓]\s*[整正]/u);
  if (!ending && !/[元圆圓角分][整正]$/u.test(tokenView)) return false;
  const terminalTail = detection.slice(ending?.[0].length ?? 0).trimStart();
  // One explicit RMB suffix may follow the ending; it cannot hide cents or
  // another marker. This is a detection copy, not a changed monetary span.
  const rmbSuffix = /^(?:人民币|人民幣|(?:RMB|CNY)(?![A-Z])|¥)\s*/iu;
  const tail = terminalTail.replace(rmbSuffix, '');
  if (tail !== terminalTail && rmbSuffix.test(tail)) return true;
  // One terminator never consumes another unit, digit, decimal or terminator.
  if (new RegExp(`^[${NUMERALS}元圆圓角分整正]|^[.．,，]\\s*[${NUMERALS}]`, 'u').test(tail)
    && !isPostposedMoneyPaymentInstruction(tail)) return true;
  const rate = attachedSuffixRate(tail);
  if (rate.present && (rate.uncertain || !rate.supported || candidate.meaning !== 'rate'
    || (candidate.rateUnit !== 'unknown' && candidate.rateUnit !== RATE_UNITS[rate.supported]))) return true;
  // Reuse the anchored currency guard on this explicit continuation edge only;
  // another sentence/person cannot attach through its existing finite grammar.
  const anchored = { ...normalized, rawValue: token, span: { start: 0, end: Array.from(token).length } };
  return sourceMoneyHasUnsupportedCurrency({ blockText: token + tail, valueStart: 0 }, anchored)
    || hasPostposedMoneyUncertainty(tail) || hasUnfinishedMoneyRangeAfter(tail)
    || isMoneyRangeEndpoint('', tokenView, tail) || attachedQualifierStatus('', tail) !== null
    || hasAttachedMoneyArithmetic('', tail);
}

export function normalizeCandidateValueV4(candidate: RawCandidateV3): NormalizedCandidateValue {
  if (candidate.kind === 'money' && (candidate.value.length > MAX_INPUT || candidate.quote.length > MAX_INPUT)) {
    const normalization = result(candidate.value, 'unsupported', '金额或引用原文超过4000字符上限，未截断解析。');
    return { value: candidate.value, amount: null, rateUnit: candidate.rateUnit, normalization };
  }
  const legacy = normalizeCandidateValue(candidate);
  if (candidate.kind === 'date' || legacy.normalization.status === 'rate_unit_mismatch') return legacy;
  let normalized = normalizeMoneyValueWithSubject(candidate.value, candidate.subject);
  if (normalized.status === 'exact') {
    const local = getCandidateLocalEvent(candidate);
    if (local.text === null) normalized = result(candidate.value, 'uncertain', '金额原文在引用中缺失或重复，无法唯一定位当前事件。');
    else {
      const offset = local.text.indexOf(candidate.value), before = local.text.slice(0, offset), after = local.text.slice(offset + candidate.value.length);
      // The unique quote anchor is already verified above. An explicit
      // arithmetic continuation can cross a layout newline outside local.text;
      // only this guard uses the complete quote, through the shared grammar.
      const quoteOffset = candidate.quote.indexOf(candidate.value);
      const arithmeticBefore = candidate.quote.slice(0, quoteOffset), arithmeticAfter = candidate.quote.slice(quoteOffset + candidate.value.length);
      const beforeBoundary = monetaryDetectionView(before).trimEnd(), afterBoundary = monetaryDetectionView(after).trimStart();
      const bareValue = !/人民[币幣]|[元圆圓¥￥]/u.test(candidate.value);
      const attachedYuan = new RegExp(`^\\s*[元圆圓](?:整|正)?(?=$|[^${NUMERALS}元圆圓角分整正])`, 'u').test(after);
      // A single whole-amount terminator at this clause's end does not add a
      // digit or subunit. Any following continuation keeps the truncation guard.
      const terminalRateTail = monetaryDetectionView(arithmeticAfter).trimStart().match(/^[整正](.*)$/su)?.[1];
      const terminalRate = terminalRateTail !== undefined ? attachedSuffixRate(terminalRateTail) : null;
      const attachedWholeTerminator = /[元圆圓角分]$/u.test(monetaryDetectionView(candidate.value))
        && (/^(?:整|正)$/u.test(afterBoundary) || (terminalRate?.postposedBy === true && terminalRate.supported !== undefined)
          || (terminalRateTail !== undefined && isPostposedMoneyPaymentInstruction(terminalRateTail)));
      const attachedPaymentInstruction = hasCompleteMoneyUnit(normalized.matchedText ?? '') && isPostposedMoneyPaymentInstruction(arithmeticAfter);
      const sourceAnchor = { blockText: local.text, valueStart: offset };
      const attachedCurrency = sourceMoneyHasExplicitRmbCurrency(sourceAnchor, normalized);
      const qualifierStatus = attachedQualifierStatus(moneyQualifierPrefixWithoutSubject(arithmeticBefore, candidate.subject), monetaryDetectionView(arithmeticAfter));
      const valueCharacters = Array.from(candidate.value), span = normalized.span;
      const rangeBefore = arithmeticBefore + (span ? valueCharacters.slice(0, span.start).join('') : '');
      const rangeToken = span ? valueCharacters.slice(span.start, span.end).join('') : candidate.value;
      const rangeAfter = (span ? valueCharacters.slice(span.end).join('') : '') + arithmeticAfter;
      // A slash explicitly names a denominator: retain unsupported units as
      // unresolved rates rather than silently treating their numerator as a
      // total. The existing finite units keep their following-prose behavior.
      // Fold only this detection copy; raw value/quote and CP spans stay intact.
      const suffixRate = attachedSuffixRate(rangeAfter), supportedRate = suffixRate.supported;
      if (hasRepeatedRmbCurrency(rangeBefore, rangeToken, rangeAfter)) normalized = result(candidate.value, 'unsupported', '原文金额重复附着币种标记，未把裁剪后的单标签金额作为精确值。');
      else if (sourceMoneyHasNonCurrencyYuan({ blockText: candidate.quote, valueStart: quoteOffset }, normalized)) normalized = result(candidate.value, 'unsupported', '原文中的元或圆属于完整普通词语，裁剪后的片段未作为人民币金额。');
      else if (sourceMoneyHasNonCurrencySubunit({ blockText: candidate.quote, valueStart: quoteOffset }, normalized)) normalized = result(candidate.value, 'unsupported', '原文中的角或分属于普通词语，裁剪后的片段未作为分币金额。');
      else if (sourceMoneyHasUnsupportedCurrency(sourceAnchor, normalized, candidate.subject)) normalized = result(candidate.value, 'unsupported', '原文金额直接附着外币或冲突币种，未换算。');
      else if (hasUnsafeWholeMoneyContinuation(candidate, normalized, arithmeticAfter)) normalized = result(candidate.value, 'unsupported', '金额终止词后的数字、币种、费率或不确定续文仍须核对，未将裁剪值作为精确金额。');
      else if (suffixRate.uncertain) normalized = result(candidate.value, 'uncertain', '当前金额的明确费率后仍附着待核或未知标记，未将裁剪值作为确定金额。');
      else if (suffixRate.present && !supportedRate) normalized = result(candidate.value, 'unsupported', '原文金额直接附着不受支持的费率单位，保留原文且未换算为总额或现有费率单位。');
      else if (supportedRate && (candidate.meaning !== 'rate' || (candidate.rateUnit !== 'unknown' && candidate.rateUnit !== RATE_UNITS[supportedRate]))) normalized = result(candidate.value, 'rate_unit_mismatch', '原文紧贴的费率单位与金额角色或候选费率单位冲突。');
      else if (isMoneyRangeEndpoint(monetaryDetectionView(rangeBefore), monetaryDetectionView(rangeToken), monetaryDetectionView(rangeAfter))) normalized = result(candidate.value, 'range', '当前金额在原文中直接属于区间端点。');
      else if (hasPostposedMoneyUncertainty(rangeAfter)) normalized = result(candidate.value, 'uncertain', '当前金额后直接附着问号、待核或未知标记，未将裁剪值作为精确金额。');
      else if (hasUnfinishedMoneyRangeAfter(arithmeticAfter)) normalized = result(candidate.value, 'uncertain', '连接词后的数字未形成完整金额或明确时间，不能确认被截取的数值可用。');
      else if (hasAttachedMoneyArithmetic(arithmeticBefore, arithmeticAfter)) normalized = result(candidate.value, 'unsupported', '当前金额在原文中直接参与倍数或算式，未把裁剪后的金额操作数当作计算结果。');
      else if (qualifierStatus) normalized = result(candidate.value, qualifierStatus, '当前金额在原文中直接附着数量不定、概数界限或正负限定，未截取为精确正数。');
      else if (/(?:可能|或许|大概|估计|待核|暂计|暂定)(?:为|工资|金额|人民币|\s)*$/u.test(monetaryDetectionView(before)) || /(?:或|或者)\s*$/u.test(before)
        || new RegExp(`^\\s*(?:或|或者)\\s*(?:${RMB_NAME}\\s*)?[${NUMERALS}]`, 'iu').test(after)) normalized = result(candidate.value, 'uncertain', '当前金额在原文中有直接附着的不确定或备选表述。');
      else if (bareValue && !attachedCurrency) normalized = result(candidate.value, 'unsupported', 'value 和当前原文锚点均无明确人民币单位，未猜测这是金额。');
      else if (new RegExp(`[${NUMERALS},.，]$`, 'u').test(beforeBoundary)
        || new RegExp(`[${NUMERALS}]+\\s*[元圆圓角分]$`, 'u').test(beforeBoundary)
        || new RegExp(`[${NUMERALS}][元圆圓]?\\s*(?:点|又|分之|加上|另加|加|减|乘|除)\\s*$`, 'u').test(beforeBoundary)
        || /^[,.，]\d/u.test(afterBoundary)
        || (!attachedYuan && !attachedWholeTerminator && !attachedPaymentInstruction && new RegExp(`^[${NUMERALS}元圆圓角分整正]`, 'u').test(afterBoundary))) normalized = result(candidate.value, 'unsupported', 'value 截去了直接相邻的金额数字或角分，未升级为精确金额。');
      // The shared edge grammar has already checked every attached bound.
      // The frozen parser's whole-string approximate test must not suppress
      // an exact token because another clause bounds a duration or a name.
      else if (legacy.normalization.status !== 'unsupported' && legacy.normalization.status !== 'multiple_amounts' && legacy.normalization.status !== 'approximate'
        && (legacy.normalization.status !== 'exact' || legacy.normalization.amount === normalized.amount)
        && !(legacy.normalization.status === 'range' && RANGE_TIME_AFTER.test(monetaryDetectionView(arithmeticAfter)))) normalized = legacy.normalization;
    }
  }
  return { value: normalized.amount ?? candidate.value, amount: normalized.amount, rateUnit: candidate.rateUnit, normalization: normalized };
}

/** A three-way gate: only positively identified non-money is safe to reject.
 * Unknown or complex input is retained for review instead of requiring an ASCII digit.
 */
export function classifyMonetaryExpression(value: string): MonetaryExpressionClassification {
  const normalization = normalizeMoneyValueV4(value);
  const detection = monetaryDetectionView(value).replace(/\s/gu, '');
  // Keep empty-label matching bounded to a complete wage or amount name.
  // This detection copy never removes a subject, numeral or unknown suffix.
  const wageName = '(?:基本|其他|其余|全部|正常|岗位|绩效|应付|已付|实付|税前|税后|拖欠|欠付|未付)?(?:工资|薪资|薪酬|劳务费|劳动报酬)';
  const wageLabel = monetaryDetectionView(value).trim().replace(/[資勞動報務費應標準稅後崗績離職試實總額計]/gu,
    character => ({ 資: '资', 勞: '劳', 動: '动', 報: '报', 務: '务', 費: '费', 應: '应', 標: '标', 準: '准', 稅: '税', 後: '后', 崗: '岗', 績: '绩', 離: '离', 職: '职', 試: '试', 實: '实', 總: '总', 額: '额', 計: '计' })[character]!);
  // A denomination alone names a currency, not an amount. Keep this bounded
  // before the explicit-currency branch; unknown/masked suffixes cannot match.
  if (/^(?:人民[币幣]|RMB|CNY|[元圆圓¥])$/iu.test(detection))
    return { kind: 'not_monetary', normalization: result(value, 'not_money', '原文仅为币种或金额单位名称，未表述金额。') };
  const currencyLabel = new RegExp(`^(?:人民[币幣]|RMB|CNY|¥)(?:${wageName}|金额|数额)(?:合计|总额|标准)?$`, 'iu');
  if (currencyLabel.test(wageLabel.replace(/\s/gu, '')) && !MASKED.test(detection))
    return { kind: 'not_monetary', normalization: result(value, 'not_money', '原文仅为币种及工资或金额标签，未表述金额。') };
  // Only a complete percentage (optionally named by a finite ratio label) is
  // definite non-money. This whole-value grammar contains no currency unit;
  // in particular 百分比 must not be cropped into 百分 as a fen amount.
  // 四万元的50% and unknown ratio prose cannot match and remain reviewable.
  const ratioNumber = `[+−负負-]?[${NUMERALS}]+(?:[.点][${NUMERALS}]+)?`;
  const ratioDescription = new RegExp(`^(?:(?:出勤率|出勤比例|支付比例|计发比例|折算比例|比例|百分比)(?:为|是|:)?)?(?:${ratioNumber}%|百分之${ratioNumber})$`, 'u');
  if (ratioDescription.test(detection.replace(/為/gu, '为'))) return { kind: 'not_monetary', normalization: result(value, 'not_money', '原文仅为比例或百分比，未表述金额。') };
  const proportionDescription = new RegExp(`^(?:打)?(?:${ratioNumber}(?:成(?:[0-9零〇一二三四五六七八九半])?|折)|半[成折]|[对對]折)$`, 'u');
  if (proportionDescription.test(detection)) return { kind: 'not_monetary', normalization: result(value, 'not_money', '原文仅为成数或折扣，未表述金额。') };
  // Whole counted compounds must precede the explicit-subunit branch. The
  // same finite words guard parsed tokens and cropped source edges, while
  // 五角钱, a true currency amount, and unknown prose remain reviewable.
  const ordinaryCount = detection.match(new RegExp(`^[${NUMERALS}]+([角分].*)$`, 'u'));
  if (ordinaryCount && isNonCurrencyAngleCountWord(ordinaryCount[1]))
    return { kind: 'not_monetary', normalization: result(value, 'not_money', '原文仅为角的计量或完整普通词语，未表述金额。') };
  const explicit = /人民[币幣]|[¥￥]/u.test(value) || monetaryExpressionHasUnsupportedCurrency(value)
    || [...value.matchAll(/[元圆圓]/gu)].some(match => isRmbCurrencyUnitAt(value, match.index))
    || [...detection.matchAll(new RegExp(`[${NUMERALS}]+[角分]`, 'gu'))]
      .some(match => !moneyTokenHasNonCurrencySubunit(match[0], detection.slice(match.index + match[0].length)));
  if (normalization.status === 'exact' || explicit) return { kind: 'monetary', normalization };
  if (MASKED.test(detection) && /工资|薪资|薪酬|金额|款项|欠薪|报酬|劳务费|付款|应付|实付|已付|尚欠|欠款/u.test(value)) return { kind: 'monetary', normalization };
  if (ordinaryCount && isNonCurrencySubunitMeasure(ordinaryCount[1]) && !MASKED.test(detection))
    return { kind: 'not_monetary', normalization: result(value, 'not_money', '原文仅为时间、计量或普通词语的计数，未表述金额。') };
  const count = `[${NUMERALS}]+`;
  const date = `(?:[${NUMERALS}]+\\s*年(?:\\s*(?:[${NUMERALS}]+月份?|元月份?|元旦)(?:\\s*[${NUMERALS}]+\\s*日)?)?|\\d{4}[-/.]\\d{1,2}(?:[-/.]\\d{1,2})?)`;
  // Keep the definite relative-month forms aligned with sourceRateUnit's
  // calendar-period boundary; the anchored wage grammar still requires no amount.
  const relativeMonth = '(?:上(?:一?个)?|下(?:一?个)?|本|当|该|这(?:个)?|某|每)月';
  // These definite day references name a wage period only inside the complete
  // amount-free description below; never remove them from an unknown amount.
  const relativeDay = '(?:(?:今|昨|明|前|后|当)(?:日|天)|本日|该日|(?:这|那)(?:日|天|一天)|同(?:日|一天)|(?:前|后|上|下)一(?:日|天)|次日|翌日)';
  const dayStage = `(?:${relativeDay}|每(?:日|天)|日|某日|该天)`;
  const wageStage = `(?:${date}(?:\\s*(?:至|到|[~～—–-])\\s*${date})?|[${NUMERALS}]+月份?|元月份?|元旦|${relativeMonth}|月|${dayStage}|离职前|入职前|入职后|试用期|本期)`;
  const wageDescription = new RegExp(`^(?:${wageStage}\\s*)?(?:的)?${wageName}(?:合计|总额|标准)?$`, 'u');
  // This separate finite wage-label view changes no amount grammar or source
  // text. Unknown/masked suffixes cannot match the complete empty-label rule.
  if (wageDescription.test(wageLabel) && !MASKED.test(detection)) return { kind: 'not_monetary', normalization: result(value, 'not_money', '原文为工资名称或期间描述，未表述金额。') };
  const ordinaryWord = /^(?:元月份?|元旦|元宵(?:节)?|元年|元素|元件|元音|[圆圓](?:满|滿|形|圈|周))$/u;
  const wageCompletion = /^(?:已|已经)?[圆圓][满滿](?:完成)?(?:工资|薪资|薪酬|劳务费|劳动报酬)(?:发放|支付|结算)(?:工作)?$/u;
  if (!MASKED.test(detection) && (ordinaryWord.test(value.trim()) || wageCompletion.test(value.trim()) || new RegExp(`^${date}$`, 'u').test(value.trim()))) return { kind: 'not_monetary', normalization: result(value, 'not_money', '原文为日期、普通词语或工资发放描述，未表述金额。') };
  const withoutDatesAndCounts = value.trim().replace(/\d{4}[-/.]\d{1,2}(?:[-/.]\d{1,2})?/gu, '')
    .replace(new RegExp(`${count}\\s*(?:年|个?月|天|日|小时|分钟|件|名(?:工人|员工|劳动者)?|(?:个|位)(?:工人|员工|劳动者)|个?人|位|个|倍|次)`, 'gu'), '')
    .replace(/(?:工资|薪资|薪酬|劳务费|劳动报酬|应付|已付|实付|月薪|日薪|时薪|工作|为|是|按月|按日|发放|支付|劳动者|每月|每年|每|共计|计|[\s，,。:：;；至到])/gu, '');
  if ((!value.trim() || !withoutDatesAndCounts) && !MASKED.test(detection)) return { kind: 'not_monetary', normalization: result(value, 'not_money', '原文仅为日期、普通计数或无金额工资描述。') };
  return { kind: 'undetermined', normalization };
}

/** A conservative comparison key, never a calculation amount.
 * Exact amounts share a key across supported spellings. For non-exact values, only an
 * anchored single amount with explicit qualifiers and an optional wage-name suffix is
 * comparable; qualifiers retain their words and positions. Complex inputs return null.
 */
export function canonicalMonetaryExpression(value: string): string | null {
  const normalization = normalizeMoneyValueV4(value);
  if (normalization.status === 'exact') return `exact:${normalization.amount}`;
  if (!['approximate', 'uncertain'].includes(normalization.status)) return null;
  // Comparison-only folding has no source offsets or calculation authority.
  // Reuse the finite qualifier grammar while retaining each word and its side:
  // 不满/不少于/不到/开外 must never collapse into each other or an exact key.
  const wrapped = monetaryDetectionView(value).trim().replace(/\s*(?:工[资資]|[劳勞][务務][费費]|[劳勞][动動][报報]酬)\s*$/u, '').trim();
  const leadingRmb = wrapped.match(/^人民[币幣]\s*/u)?.[0] ?? '';
  const text = wrapped.slice(leadingRmb.length);
  const prefix = text.match(new RegExp(`^(${MONEY_BOUND_PREFIX}|近|可能|或许|大概|估计|不确定|待核|暂计|暂定)\\s*`, 'u'));
  const suffix = text.match(new RegExp(`\\s*(${MONEY_BOUND_SUFFIX})$`, 'u'));
  const start = prefix?.[0].length ?? 0, end = suffix ? text.length - suffix[0].length : text.length;
  if (end <= start) return null;
  let literal = text.slice(start, end).trim();
  const inner = literal.match(new RegExp(`^(?:人民[币幣]\\s*)?([${NUMERALS},.，]+)(多|余)([元圆圓])$`, 'u'));
  if (inner) {
    // This synthetic literal exists only to derive a comparison key; no source span,
    // normalized candidate, or calculation amount is created from repaired evidence.
    const base = normalizeMoneyValueV4(`${inner[1]}${inner[3]}`);
    return base.status === 'exact' ? `${normalization.status}:${prefix?.[1] ?? ''}:${base.amount}:${suffix?.[1] ?? ''}:inner=${inner[2]}` : null;
  }
  if (!prefix && !suffix) return null;
  let exact = normalizeMoneyValueV4(literal);
  // The outer currency was removed only to locate the finite qualifier. A
  // subunit literal still needs that same explicit RMB; never infer it naked.
  if (exact.status !== 'exact' && leadingRmb) {
    literal = leadingRmb + literal;
    exact = normalizeMoneyValueV4(literal);
  }
  // Whole-literal anchoring prevents removing a wage noun from a complex narrative.
  if (exact.status !== 'exact' || exact.matchedText !== literal) return null;
  return `${normalization.status}:${prefix?.[1] ?? ''}:${exact.amount}:${suffix?.[1] ?? ''}`;
}
